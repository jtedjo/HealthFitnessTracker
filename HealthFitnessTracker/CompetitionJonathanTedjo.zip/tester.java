public class tester{
	public static void main(String[] args){


		InputFrame f = new InputFrame();
		f.setVisible(true);
		

		

		

	}
}
